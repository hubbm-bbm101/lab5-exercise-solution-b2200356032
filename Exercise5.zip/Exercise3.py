from random import randint

number = randint(1,1001)
i = 10
while i > 0:
    a = int(input("Pick a number:"))
    if a == number:
        print("Congratulations! You've won!")
        break

    else:
        if a < number:
            print("Choose a bigger one!")
            i -= 1
            print("Remaining guess count: {}".format(i))
        elif a > number:
            print("Choose a smaller one!")
            i -= 1
            print("Remaining guess count: {}".format(i))
print("You've lost! The correct number was {}".format(number))






