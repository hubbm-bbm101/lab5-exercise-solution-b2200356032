def counter_function(N):
    b = sum(range(1,N+1,2))
    print("The sum of the odd number between 1 and {} including {} is {}".format(N,N,b))
    c = 0
    for i in range (2,N+1,2):
        c += i
    count = len(range(2,N+1,2))
    avg = c/count
    print("The average of the even numbers between 1 and {} including {} is {}".format(N,N,avg))

while True:
    N = input("Please insert a number(if you want to quit please press q):")
    if N == "q":
        print("The program is being stopped...")
        break
    else:   
        N = int(N)
        counter_function(N)


    

        
