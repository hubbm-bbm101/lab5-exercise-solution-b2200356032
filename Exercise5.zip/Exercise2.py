user_email = input("Please enter your e-mail:")

def valid(e_mail):
    if user_email.count("@") == 1 and "." in user_email:
        print("This is a valid e_mail address.")
    else:
        print("This e_mail is not valid..")

valid(user_email)